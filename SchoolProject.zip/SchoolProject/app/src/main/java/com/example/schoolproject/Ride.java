package com.example.schoolproject;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import static com.example.schoolproject.GameView.screenRatioX;
import static com.example.schoolproject.GameView.screenRatioY;

public class Ride {
    public boolean isGoingUp= false;
    int toShoot = 0;
    int x,y, width, height;
    int bulletCounter = 0;
    Bitmap tank;
    private GameView gameView;

    Ride(GameView gameView,int screenY, Resources res){

        tank = BitmapFactory.decodeResource(res, R.drawable.tank);
        this.gameView = gameView;
        width = tank.getWidth();
        height = tank.getHeight();

        width *= 2;
        height *= 2;

        width *= (int)screenRatioX;
        height *= (int)screenRatioY;

        tank = Bitmap.createScaledBitmap(tank,width,height,false);

        y = screenY / 2;
        x = (int) (64 * screenRatioX);
    }
    Bitmap getRide(){
        if(toShoot != 0) {
            toShoot--;
            gameView.newBullet();
        }
        return tank;
    }

}
